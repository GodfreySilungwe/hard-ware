const express = require('express');
const CashEntry = require('../models/CashEntry');
const CashSession = require('../models/CashSession');
const Customer = require('../models/Customer');
const { protect, isHardwareManagerOrOwner } = require('../middleware/auth');
const { findOpenSession, ensureOpenSession, normalizeAmount, recordCashEntry } = require('../lib/cashLedger');
const { settleCustomerCreditBalance } = require('../lib/customerAccountSync');

const router = express.Router();

const tenantRecords = (records, req) => {
  const tenantId = req.user?.tenantId || null;
  return (records || []).filter((record) => !tenantId || record.tenantId === tenantId);
};

const getSessionEntries = async (sessionId, req) => tenantRecords(
  await CashEntry.find(sessionId ? { sessionId } : {}, req),
  req
);

const getEntriesForSession = (entries, session) => {
  if (!session) return [];
  const sessionId = session._id || session.id;
  const openedAt = session.openedAt || session.createdAt;
  return entries.filter((entry) => {
    if (entry.sessionId && String(entry.sessionId) === String(sessionId)) return true;
    if (entry.sessionId || !openedAt) return false;
    return new Date(entry.occurredAt || entry.createdAt || 0) >= new Date(openedAt);
  });
};

const calculateBalance = (entries, openingFloat = 0) => normalizeAmount(
  normalizeAmount(openingFloat) + entries.reduce((balance, entry) => (
    balance + (entry.direction === 'out' ? -Number(entry.amount || 0) : Number(entry.amount || 0))
  ), 0)
);

const summarizeSessionEntries = (entries = []) => entries.reduce((summary, entry) => {
  const amount = Number(entry.amount || 0);
  const isOutflow = entry.direction === 'out';
  const type = entry.type || 'adjustment';

  if (type === 'sale' || type === 'credit_sale_payment') summary.salesReceipts += amount;
  if (type === 'receivable_payment') summary.receivableCollections += amount;
  if (type === 'expense') summary.expenses += amount;
  if (type === 'sale_reversal') summary.reversals += amount;
  if (type === 'adjustment') summary.adjustments += isOutflow ? -amount : amount;
  return summary;
}, {
  salesReceipts: 0,
  receivableCollections: 0,
  expenses: 0,
  reversals: 0,
  adjustments: 0
});

router.get('/summary', protect, async (req, res) => {
  try {
    const [sessions, entries] = await Promise.all([
      CashSession.find({}, req),
      CashEntry.find({}, req)
    ]);
    const scopedSessions = tenantRecords(sessions, req);
    const scopedEntries = tenantRecords(entries, req);
    const openSession = scopedSessions.find((session) => session.status === 'open') || null;
    const selectedSession = req.query.sessionId
      ? scopedSessions.find((session) => (session._id || session.id) === req.query.sessionId)
      : openSession;
    const sessionEntries = getEntriesForSession(scopedEntries, selectedSession);
    const sessionMetrics = summarizeSessionEntries(sessionEntries);
    const accountBalances = {};

    if (selectedSession) {
      accountBalances.cash = normalizeAmount(selectedSession.openingFloat || 0);
    }

    for (const entry of sessionEntries) {
      const account = entry.account || 'cash';
      accountBalances[account] = normalizeAmount((accountBalances[account] || 0) + (
        entry.direction === 'out' ? -Number(entry.amount || 0) : Number(entry.amount || 0)
      ));
    }

    res.json({
      openSession,
      session: selectedSession,
      balance: calculateBalance(sessionEntries, selectedSession?.openingFloat || 0),
      cashMetrics: {
        openingFloat: normalizeAmount(selectedSession?.openingFloat || 0),
        salesReceipts: normalizeAmount(sessionMetrics.salesReceipts),
        receivableCollections: normalizeAmount(sessionMetrics.receivableCollections),
        expenses: normalizeAmount(sessionMetrics.expenses),
        reversals: normalizeAmount(sessionMetrics.reversals),
        adjustments: normalizeAmount(sessionMetrics.adjustments),
        expectedCash: calculateBalance(sessionEntries, selectedSession?.openingFloat || 0),
        countedCash: selectedSession?.countedCash === undefined ? null : normalizeAmount(selectedSession.countedCash),
        variance: selectedSession?.variance === undefined ? null : normalizeAmount(selectedSession.variance),
        varianceExplanation: selectedSession?.varianceExplanation || null
      },
      accountBalances,
      entries: sessionEntries.sort((left, right) => new Date(right.occurredAt || right.createdAt || 0) - new Date(left.occurredAt || left.createdAt || 0))
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.get('/entries', protect, async (req, res) => {
  try {
    const entries = await getSessionEntries(req.query.sessionId, req);
    const filtered = entries
      .filter((entry) => !req.query.account || entry.account === req.query.account)
      .filter((entry) => !req.query.type || entry.type === req.query.type)
      .sort((left, right) => new Date(right.occurredAt || right.createdAt || 0) - new Date(left.occurredAt || left.createdAt || 0));
    res.json(filtered);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/sessions', protect, isHardwareManagerOrOwner, async (req, res) => {
  try {
    if (await findOpenSession(req)) return res.status(400).json({ message: 'A cash session is already open' });
    const openingFloat = normalizeAmount(req.body?.openingFloat);
    if (openingFloat < 0) return res.status(400).json({ message: 'Opening float cannot be negative' });
    const session = await ensureOpenSession(req, openingFloat);
    res.status(201).json(session);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.post('/sessions/:id/close', protect, isHardwareManagerOrOwner, async (req, res) => {
  try {
    const session = await CashSession.findById(req.params.id, req);
    if (!session || session.status !== 'open') return res.status(404).json({ message: 'Open cash session not found' });
    const entries = await getSessionEntries(req.params.id, req);
    const expectedClosing = calculateBalance(entries, session.openingFloat);
    const countedCash = normalizeAmount(req.body?.countedCash);
    if (countedCash < 0) return res.status(400).json({ message: 'Counted cash cannot be negative' });
    const variance = normalizeAmount(countedCash - expectedClosing);
    const varianceExplanation = String(req.body?.varianceExplanation || '').trim();
    if (variance !== 0 && !varianceExplanation) {
      return res.status(400).json({ message: 'A variance explanation is required when counted cash differs from expected cash' });
    }
    session.expectedClosing = expectedClosing;
    session.countedCash = countedCash;
    session.variance = variance;
    session.varianceExplanation = varianceExplanation || null;
    session.status = 'closed';
    session.closedAt = new Date().toISOString();
    session.closedBy = req.user?.id || req.user?._id || null;
    await session.save();
    res.json(session);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.post('/entries', protect, isHardwareManagerOrOwner, async (req, res) => {
  try {
    const amount = normalizeAmount(req.body?.amount);
    if (amount <= 0) return res.status(400).json({ message: 'Amount must be greater than zero' });
    const direction = req.body?.direction || (req.body?.type === 'expense' ? 'out' : 'in');
    const entry = await recordCashEntry({
      req,
      amount,
      direction,
      account: req.body?.account || 'cash',
      type: req.body?.type || 'adjustment',
      category: req.body?.category || null,
      description: req.body?.description || '',
      sourceType: 'manual',
      sourceKey: req.body?.idempotencyKey || null
    });
    res.status(201).json(entry);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

router.post('/receivables/payments', protect, async (req, res) => {
  try {
    const customer = await Customer.findById(req.body?.customerId, req);
    if (!customer) return res.status(404).json({ message: 'Customer not found' });
    const amount = normalizeAmount(req.body?.amount);
    const balance = normalizeAmount(customer.creditBalance);
    if (amount <= 0 || amount > balance) return res.status(400).json({ message: 'Payment must be greater than zero and cannot exceed the customer balance' });
    settleCustomerCreditBalance(customer, amount);
    customer.creditSettlements = Array.isArray(customer.creditSettlements) ? customer.creditSettlements : [];
    customer.creditSettlements.push({ amount, settledAt: new Date().toISOString(), account: req.body?.account || 'cash' });
    await customer.save();
    const entry = await recordCashEntry({
      req,
      amount,
      account: req.body?.account || 'cash',
      type: 'receivable_payment',
      description: req.body?.description || `Payment from ${customer.name || 'customer'}`,
      customerId: customer._id || customer.id,
      sourceType: 'customer',
      sourceId: customer._id || customer.id,
      sourceKey: req.body?.idempotencyKey || `receivable:${customer._id || customer.id}:${Date.now()}`
    });
    res.status(201).json({ customer, entry });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;