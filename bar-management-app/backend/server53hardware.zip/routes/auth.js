const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { PutObjectCommand, S3Client } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const User = require('../models/User');
const Tenant = require('../models/Tenant');
const TenantInvite = require('../models/TenantInvite');
const dynamodb = require('../lib/dynamodb');
const { protect, isOwner, isOwnerOrHardwareManager, isHardwareManagerOrOwner } = require('../middleware/auth');
const { DEFAULT_PAYMENT_METHODS, normalizePaymentMethods } = require('../lib/paymentMethods');
const { normalizeCurrencyCode, isValidCurrencyCode } = require('../lib/currency');
const {
  DEFAULT_GRACE_PERIOD_DAYS,
  MAX_GRACE_PERIOD_DAYS,
  MAX_GRACE_PERIOD_MONTHS,
  buildSubscriptionDates,
  getSubscriptionAccess,
  normalizeTermDays,
  normalizeTermMonths
} = require('../lib/subscriptions');

const jwtSecret = process.env.JWT_SECRET || 'secret_key';
const s3Region = process.env.AWS_REGION || 'us-east-1';
const s3BucketName = 'hardwaresamplefiles3bucket';
const s3Client = new S3Client({ region: s3Region });
const WHATSAPP_REQUEST_TIMEOUT_MS = 3000;

const isDeletedTenant = (tenant) => (
  String(tenant?.status || '').toLowerCase() === 'deleted'
  || tenant?.isDeleted === true
  || tenant?.deleted === true
  || Boolean(tenant?.deletedAt)
);

const DEFAULT_BUSINESS_SETTINGS = {
  name: '',
  address: '',
  phone: '',
  email: '',
  taxId: '',
  taxCompliant: false,
  taxRate: 17.5,
  currency: 'MWK',
  paymentMethods: DEFAULT_PAYMENT_METHODS,
  bankName: '',
  bankBranch: '',
  bankAccountName: '',
  bankAccountNumber: '',
  receiptFooter: 'Thank you for your business!',
  logo: '',
  logoKey: ''
};

function getTenantAccessMessage(status) {
  switch (status) {
    case 'suspended':
      return 'This hardware is suspended. Please contact support.';
    case 'deleted':
      return 'This hardware has been deleted and cannot be used.';
    default:
      return null;
  }
}

function getSubscriptionLoginMessage(subscription) {
  if (subscription?.status === 'pending') {
    return 'This hardware subscription is awaiting activation. Please contact support.';
  }
  if (subscription?.status === 'cancelled') {
    return 'This hardware subscription has been cancelled. Please contact support.';
  }
  return 'This hardware subscription has expired. Please renew to continue using the app.';
}

function getOwnerConfig() {
  return {
    username: process.env.DEFAULT_OWNER_USERNAME || 'silungwegod@gmail.com',
    email: process.env.DEFAULT_OWNER_EMAIL || 'silungwegod@gmail.com',
    password: process.env.DEFAULT_OWNER_PASSWORD || 'godfrey1234',
    fullName: process.env.DEFAULT_OWNER_FULL_NAME || 'Godfrey Silungwe',
    phone: process.env.DEFAULT_OWNER_PHONE || '0995718815',
    role: 'owner'
  };
}

function normalizeLoginIdentifier(value) {
  return String(value || '').trim().toLowerCase();
}

function normalizeShopName(value) {
  return String(value || '').trim();
}

function getShopNameValidationError(value) {
  const shopName = normalizeShopName(value);
  if (!shopName) return 'Shop name is required.';
  if (shopName.length > 120) return 'Shop name must be 120 characters or fewer.';
  return null;
}

function normalizeShopProfile(data = {}) {
  const town = String(data.town || data.tradingCenter || '').trim();
  return {
    country: String(data.country || '').trim(),
    district: String(data.district || '').trim(),
    town,
    tradingCenter: town,
    shopDescription: String(data.shopDescription || '').trim()
  };
}

function getShopProfileValidationError(profile) {
  if (!profile.country) return 'Country is required.';
  if (!profile.district) return 'District is required.';
  if (!profile.town) return 'Town is required.';
  if (!profile.shopDescription) return 'Please briefly describe what the shop sells.';
  if (profile.country.length > 100) return 'Country must be 100 characters or fewer.';
  if (profile.district.length > 100) return 'District must be 100 characters or fewer.';
  if (profile.town.length > 120) return 'Town must be 120 characters or fewer.';
  if (profile.shopDescription.length > 300) return 'Shop description must be 300 characters or fewer.';
  return null;
}

function getRegistrationConflicts(users, { username, email, tenantId }) {
  const normalizedUsername = normalizeLoginIdentifier(username);
  const normalizedEmail = normalizeLoginIdentifier(email);
  return {
    usernameExists: (users || []).some((user) => normalizeLoginIdentifier(user.username) === normalizedUsername),
    emailExistsInTenant: Boolean(tenantId) && (users || []).some((user) => (
      normalizeLoginIdentifier(user.email) === normalizedEmail
      && String(user.tenantId || '') === String(tenantId)
    ))
  };
}

function resolveLoginIdentity(users, identifier) {
  const normalizedIdentifier = normalizeLoginIdentifier(identifier);
  const usernameMatches = (users || []).filter((user) => (
    normalizeLoginIdentifier(user.username) === normalizedIdentifier
  ));
  if (usernameMatches.length > 1) return { user: null, ambiguousUsername: true, requiresUsername: false };
  if (usernameMatches.length === 1) {
    return { user: usernameMatches[0], ambiguousUsername: false, requiresUsername: false };
  }

  const emailMatches = (users || []).filter((user) => (
    normalizeLoginIdentifier(user.email) === normalizedIdentifier
  ));
  if (emailMatches.length > 1) {
    return { user: null, ambiguousUsername: false, requiresUsername: true };
  }
  return { user: emailMatches[0] || null, ambiguousUsername: false, requiresUsername: false };
}

function buildApprovalMessage(user = {}) {
  const fullName = user.fullName || user.username || 'there';
  const username = user.username || 'your username';
  const password = user.password || 'the password you chose';
  return [
    `Hello ${fullName}, your hardware manager account has been approved.`,
    `Please log in using your username: ${username} and password: ${password}.`,
    'After signing in, use the dashboard to manage products, inventory, customers, and orders.',
    'If you need help, contact the global owner.'
  ].join(' ');
}

function buildManagerInstructions(user = {}) {
  const fullName = user.fullName || user.username || 'there';
  return [
    `Hello ${fullName}, you are now a Hardware Manager.`,
    'Use your dashboard to manage products, categories, inventory, suppliers, purchase orders, and reports.',
    'Create sales team members from the settings area so they can handle POS, customers, and orders.',
    'You can approve applications, monitor hardware accounts, and keep your team working from the hardware-level menus.'
  ].join(' ');
}

async function sendWhatsAppApprovalMessage(user = {}, customMessage = null) {
  const phone = user.phone || user.mobile || user.whatsappNumber || process.env.WHATSAPP_TO_NUMBER || '+265995718815';
  const message = customMessage || buildApprovalMessage(user);
  
  if (!phone) {
    return { sent: false, reason: 'Missing phone number' };
  }

  const baseUrl = process.env.WHATSAPP_API_URL;
  const token = process.env.WHATSAPP_API_TOKEN;

  if (baseUrl && token) {
    try {
      const response = await fetch(baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        signal: AbortSignal.timeout(WHATSAPP_REQUEST_TIMEOUT_MS),
        body: JSON.stringify({
          to: phone,
          message
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || 'WhatsApp delivery failed');
      }

      return { sent: true, provider: 'configured' };
    } catch (error) {
      console.error('WhatsApp approval message error:', error.message);
      return { sent: false, reason: error.message };
    }
  }

  try {
    const fallbackUrl = `https://api.callmebot.com/whatsapp.php?phone=${encodeURIComponent(phone)}&text=${encodeURIComponent(message)}`;
    const response = await fetch(fallbackUrl, {
      method: 'GET',
      signal: AbortSignal.timeout(WHATSAPP_REQUEST_TIMEOUT_MS)
    });
    if (!response.ok) {
      throw new Error('Fallback WhatsApp provider rejected the request');
    }
    return { sent: true, provider: 'fallback' };
  } catch (error) {
    console.error('Fallback WhatsApp approval message error:', error.message);
    return { sent: false, reason: error.message };
  }
}

function buildRegistrationOnboardingMessage({ fullName, username, password }) {
  const displayName = fullName || username || 'there';
  return `Hello ${displayName}, your Hardware Manager account is created. Use username ${username} and password ${password} to log in, then reset your password in Settings. In the app you can manage products, categories, suppliers, inventory, customers, create sales from POS, and view orders and reports.`;
}

function shouldPromoteToOwner(user, ownerConfig = getOwnerConfig()) {
  if (!user) return false;

  if (user.role === 'owner') return true;
  if (user.role === 'hardware-manager') return false;

  const normalizedUsername = (user.username || '').toLowerCase();
  const normalizedEmail = (user.email || '').toLowerCase();
  const ownerUsername = (ownerConfig?.username || '').toLowerCase();
  const ownerEmail = (ownerConfig?.email || '').toLowerCase();

  return normalizedUsername === ownerUsername || normalizedEmail === ownerEmail;
}

function isHardwareManagerUser(user, ownerConfig = getOwnerConfig()) {
  if (!user || user.role !== 'hardware-manager') {
    return false;
  }

  const normalizedUsername = (user.username || '').toLowerCase();
  const normalizedEmail = (user.email || '').toLowerCase();
  const ownerUsername = (ownerConfig?.username || '').toLowerCase();
  const ownerEmail = (ownerConfig?.email || '').toLowerCase();

  return normalizedUsername !== ownerUsername && normalizedEmail !== ownerEmail;
}

async function deleteTenantAndRelatedData(tenantId, userId = null) {
  if (!tenantId && !userId) return;

  const entityTypes = ['tenant', 'tenantinvite', 'user', 'category', 'customer', 'inventoryadjustment', 'order', 'product', 'purchaseorder', 'supplier'];

  for (const entityType of entityTypes) {
    const records = await dynamodb.listEntities(entityType);
    const matches = (records || []).filter((record) => {
      const recordTenantId = record?.tenantId || null;
      const recordOwnerId = record?.ownerId || null;
      const recordId = record?.id || record?._id || null;

      return (
        (tenantId && recordTenantId === tenantId) ||
        (userId && (recordOwnerId === userId || recordId === userId))
      );
    });

    for (const record of matches) {
      const recordId = record?.id || record?._id;
      if (recordId) {
        await dynamodb.deleteEntity(entityType, recordId);
      }
    }
  }
}

async function normalizeOwnerAccount(user) {
  if (!user) return null;

  const ownerConfig = getOwnerConfig();
  const shouldBeOwner = shouldPromoteToOwner(user, ownerConfig) && user.role !== 'hardware-manager';

  if (!shouldBeOwner) {
    return null;
  }

  const updates = {};

  if (user.role !== 'owner') {
    updates.role = 'owner';
  }

  if (user.tenantId) {
    updates.tenantId = null;
  }

  if (!user.isActive) {
    updates.isActive = true;
  }

  if (!user.fullName && ownerConfig.fullName) {
    updates.fullName = ownerConfig.fullName;
  }

  if (!user.phone && ownerConfig.phone) {
    updates.phone = ownerConfig.phone;
  }

  if (user.registrationStatus === 'pending' || user.registrationStatus === 'rejected') {
    updates.registrationStatus = 'approved';
  }

  if (Object.keys(updates).length > 0) {
    Object.assign(user, updates);
    await user.save();
  }

  return user;
}

async function ensureDefaultOwnerUser() {
  const ownerConfig = getOwnerConfig();

  const existingOwners = await User.find({ role: 'owner' });
  const matchingOwner = (existingOwners || []).find((candidate) => {
    const candidateEmail = (candidate.email || '').toLowerCase();
    const candidateUsername = (candidate.username || '').toLowerCase();
    const configuredEmail = (ownerConfig.email || '').toLowerCase();
    const configuredUsername = (ownerConfig.username || '').toLowerCase();

    return candidateEmail === configuredEmail || candidateUsername === configuredUsername || candidate.role === 'owner';
  });

  const existingOwner = matchingOwner || existingOwners?.[0] || null;

  if (existingOwner) {
    const updates = {};

    if (existingOwner.role !== 'owner') {
      updates.role = 'owner';
    }

    if (existingOwner.tenantId) {
      updates.tenantId = null;
    }

    if (!existingOwner.fullName && ownerConfig.fullName) {
      updates.fullName = ownerConfig.fullName;
    }

    if (!existingOwner.phone && ownerConfig.phone) {
      updates.phone = ownerConfig.phone;
    }

    if (!existingOwner.isActive) {
      updates.isActive = true;
    }

    if (existingOwner.registrationStatus === 'pending' || existingOwner.registrationStatus === 'rejected') {
      updates.registrationStatus = 'approved';
    }

    if (Object.keys(updates).length > 0) {
      Object.assign(existingOwner, updates);
      await existingOwner.save();
    }

    return existingOwner;
  }

  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(ownerConfig.password, salt);
  const owner = new User({
    ...ownerConfig,
    password: hashedPassword,
    isActive: true,
    registrationStatus: 'approved'
  });

  await owner.save();
  return owner;
}

// Register (approval-based tenant signup)
router.post('/register', async (req, res) => {
  try {
    await ensureDefaultOwnerUser();

    const { inviteToken, tenantName, hardwareName } = req.body || {};
    const username = String(req.body?.username || '').trim();
    const email = String(req.body?.email || '').trim();
    const password = req.body?.password;
    const fullName = String(req.body?.fullName || '').trim();
    const shopName = normalizeShopName(req.body?.shopName);
    const shopNameError = getShopNameValidationError(shopName);
    if (shopNameError) {
      return res.status(400).json({ message: shopNameError });
    }
    const shopProfile = normalizeShopProfile(req.body);
    const shopProfileError = getShopProfileValidationError(shopProfile);
    if (shopProfileError) {
      return res.status(400).json({ message: shopProfileError });
    }
    if (!username || !email || !password || !fullName) {
      return res.status(400).json({ message: 'Username, email, full name, and password are required.' });
    }

    const registrationUsers = await User.find();
    const usernameConflict = getRegistrationConflicts(registrationUsers, { username, email }).usernameExists;
    if (usernameConflict) {
      return res.status(400).json({ message: 'Username is already in use. Choose a unique username.' });
    }

    let tenant = null;
    if (inviteToken) {
      const invite = await TenantInvite.findOne({ token: inviteToken });
      if (!invite || invite.status !== 'approved') {
        return res.status(400).json({ message: 'Invite not found or not approved' });
      }
      tenant = await Tenant.findById(invite.tenantId);
    }

    const tenantId = tenant?._id || tenant?.id;
    const emailConflict = getRegistrationConflicts(registrationUsers, { username, email, tenantId }).emailExistsInTenant;
    if (emailConflict) {
      return res.status(400).json({ message: 'An account with this email already exists for this shop.' });
    }

    if (!tenant && tenantName) {
      tenant = new Tenant({
        name: tenantName,
        hardwareName: hardwareName || tenantName,
        shopName,
        ...shopProfile,
        status: 'pending',
        ownerId: null
      });
      await tenant.save();
    } else if (tenant && !tenant.shopName) {
      tenant.shopName = shopName;
      await tenant.save();
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const user = new User({
      username,
      email,
      phone: req.body?.phone || req.body?.whatsappNumber || null,
      password: hashedPassword,
      fullName,
      shopName,
      ...shopProfile,
      role: 'hardware-manager',
      tenantId: tenant ? tenant._id || tenant.id : null,
      isActive: false,
      registrationStatus: 'pending'
    });

    await user.save();

    const onboardMessage = buildRegistrationOnboardingMessage({
      fullName: user.fullName,
      username: user.username,
      password
    });
    const whatsappResult = await sendWhatsAppApprovalMessage({ phone: user.phone, fullName: user.fullName, username: user.username }, onboardMessage);

    res.status(201).json({
      message: 'Registration submitted for owner approval',
      whatsappSent: whatsappResult.sent,
      whatsappNote: whatsappResult.sent ? 'Onboarding message sent.' : whatsappResult.reason,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        tenantId: user.tenantId
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: error.message });
  }
});

// Owner-only hardware manager creation
router.post('/create-hardware-manager', protect, isOwner, async (req, res) => {
  try {
    const { username, email, phone, password, fullName, tenantName, hardwareName, shopName } = req.body || {};
    const normalizedShopName = normalizeShopName(shopName);
    const shopNameError = getShopNameValidationError(normalizedShopName);
    if (shopNameError) {
      return res.status(400).json({ message: shopNameError });
    }
    const shopProfile = normalizeShopProfile(req.body);
    const shopProfileError = getShopProfileValidationError(shopProfile);
    if (shopProfileError) {
      return res.status(400).json({ message: shopProfileError });
    }

    if (!username || !email || !password || !fullName || !tenantName || !hardwareName || !phone) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const registrationUsers = await User.find();
    if (getRegistrationConflicts(registrationUsers, { username, email }).usernameExists) {
      return res.status(400).json({ message: 'Username is already in use. Choose a unique username.' });
    }

    const tenant = new Tenant({
      name: tenantName,
      hardwareName,
      shopName: normalizedShopName,
      ...shopProfile,
      status: 'active',
      ownerId: req.user?._id || req.user?.id
    });
    await tenant.save();

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const manager = new User({
      username,
      email,
      phone,
      password: hashedPassword,
      fullName,
      shopName: normalizedShopName,
      ...shopProfile,
      role: 'hardware-manager',
      tenantId: tenant._id || tenant.id,
      isActive: true
    });
    await manager.save();

    res.status(201).json({
      tenant,
      user: {
        id: manager._id,
        username: manager.username,
        email: manager.email,
        phone: manager.phone,
        fullName: manager.fullName,
        role: manager.role,
        tenantId: manager.tenantId
      }
    });
  } catch (error) {
    console.error('Hardware manager creation error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.get('/pending-registrations', protect, isOwner, async (req, res) => {
  try {
    const users = await User.find({ isActive: false });
    const pending = users.filter((user) => {
      if (user.role !== 'hardware-manager' && user.role !== 'owner') {
        return false;
      }
      return user.registrationStatus !== 'rejected' && user.registrationStatus !== 'approved';
    });
    res.json(pending);
  } catch (error) {
    console.error('Pending registrations error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.post('/approve-registration/:id', protect, isOwner, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'Registration not found' });
    }

    if (user.isActive) {
      return res.status(400).json({ message: 'Registration already approved' });
    }

    let tenant = null;
    if (user.tenantId) {
      tenant = await Tenant.findById(user.tenantId);
      if (!tenant) {
        return res.status(401).json({ message: 'Tenant not found' });
      }
    }

    const approvedShopName = normalizeShopName(req.body?.shopName || user.shopName || tenant?.shopName);
    const shopNameError = getShopNameValidationError(approvedShopName);
    if (shopNameError) {
      return res.status(400).json({ message: shopNameError });
    }
    const shopProfile = normalizeShopProfile({
      country: req.body?.country || tenant?.country || user.country,
      district: req.body?.district || tenant?.district || user.district,
      town: req.body?.town || req.body?.tradingCenter || tenant?.town || tenant?.tradingCenter || user.town || user.tradingCenter,
      shopDescription: req.body?.shopDescription || tenant?.shopDescription || user.shopDescription
    });
    const shopProfileError = getShopProfileValidationError(shopProfile);
    if (shopProfileError) {
      return res.status(400).json({ message: shopProfileError });
    }

    if (!tenant) {
      tenant = new Tenant({
        name: req.body?.tenantName || user.fullName || 'Hardware',
        hardwareName: req.body?.hardwareName || req.body?.tenantName || user.fullName || 'Hardware',
        shopName: approvedShopName,
        ...shopProfile,
        status: 'active',
        ownerId: req.user?._id || req.user?.id
      });
      await tenant.save();
      user.tenantId = tenant._id || tenant.id;
    }

    const updatedShopProfile = { shopName: approvedShopName, ...shopProfile };
    const shopProfileChanged = Object.entries(updatedShopProfile).some(([key, value]) => tenant[key] !== value);
    if (shopProfileChanged) {
      Object.assign(tenant, updatedShopProfile);
      await tenant.save();
    }

    if (tenant.status !== 'active') {
      tenant.status = 'active';
      await tenant.save();
    }

    user.isActive = true;
    user.role = 'hardware-manager';
    user.registrationStatus = 'approved';
    Object.assign(user, { shopName: approvedShopName, ...shopProfile });
    await user.save();

    const approvalMessage = buildApprovalMessage({
      ...user,
      password: req.body?.temporaryPassword || req.body?.password || 'the password you chose'
    });
    const managerInstructions = buildManagerInstructions(user);
    const whatsappResult = await sendWhatsAppApprovalMessage({
      ...user,
      phone: req.body?.whatsappNumber || user.phone || user.mobile || process.env.WHATSAPP_TO_NUMBER,
      password: req.body?.temporaryPassword || req.body?.password || 'the password you chose'
    });

    res.json({
      message: 'Registration approved successfully',
      tenant,
      whatsappMessage: approvalMessage,
      whatsappSent: whatsappResult.sent,
      whatsappNote: whatsappResult.sent ? 'WhatsApp notification sent.' : whatsappResult.reason,
      managerInstructions,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        tenantId: user.tenantId
      }
    });
  } catch (error) {
    console.error('Approve registration error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.post('/reject-registration/:id', protect, isOwner, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'Registration not found' });
    }

    if (user.registrationStatus === 'rejected') {
      return res.status(400).json({ message: 'Registration already rejected' });
    }

    await deleteTenantAndRelatedData(user.tenantId, user._id || user.id);
    await user.delete();

    res.json({
      message: 'Registration rejected and its data removed',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Reject registration error:', error);
    res.status(500).json({ message: error.message });
  }
});

// Owner or hardware-manager sales account creation
router.post('/create-sales-account', protect, isOwnerOrHardwareManager, async (req, res) => {
  try {
    const { username, email, password, fullName, phone } = req.body || {};
    const normalizedEmail = String(email || '').trim();
    const tenantId = req.user?.tenantId;

    if (!username || !phone || !password || !fullName) {
      return res.status(400).json({ message: 'Username, phone, password, and full name are required' });
    }

    const existingUser = await User.findOne({
      $or: [{ username }, ...(normalizedEmail ? [{ email: normalizedEmail }] : [])]
    });

    if (existingUser) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const user = new User({
      username,
      email: normalizedEmail,
      phone,
      password: hashedPassword,
      fullName,
      role: 'sales',
      tenantId,
      isActive: true
    });

    await user.save();

    res.status(201).json({
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        phone: user.phone,
        fullName: user.fullName,
        role: user.role,
        tenantId: user.tenantId,
        initialPassword: password
      }
    });
  } catch (error) {
    console.error('Sales account creation error:', error);
    res.status(500).json({ message: error.message });
  }
});

// Tenant sales user list for hardware managers, global list for owner
router.get('/sales-accounts', protect, isHardwareManagerOrOwner, async (req, res) => {
  try {
    const query = { role: 'sales' };

    if (req.user.role !== 'owner') {
      if (!req.user?.tenantId) {
        return res.status(403).json({ message: 'Tenant access required' });
      }
      query.tenantId = req.user.tenantId;
    }

    let salesUsers = await User.find(query);
    if (req.user.role === 'owner') {
      const tenants = (await Tenant.find()).filter((tenant) => !isDeletedTenant(tenant));
      const activeTenantIds = new Set(tenants.map((tenant) => String(tenant._id || tenant.id)));
      salesUsers = salesUsers.filter((sales) => activeTenantIds.has(String(sales.tenantId || '')));
    }
    const normalized = salesUsers.map((sales) => ({
      id: sales._id || sales.id,
      username: sales.username,
      email: sales.email,
      phone: sales.phone,
      fullName: sales.fullName,
      tenantId: sales.tenantId,
      isActive: sales.isActive,
      initialPassword: sales.initialPassword || 'Not available',
      createdAt: sales.createdAt,
      updatedAt: sales.updatedAt
    }));
    res.json(normalized);
  } catch (error) {
    console.error('Sales accounts list error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.delete('/sales-accounts/:id', protect, isHardwareManagerOrOwner, async (req, res) => {
  try {
    const salesUser = await User.findById(req.params.id);
    if (!salesUser || salesUser.role !== 'sales') {
      return res.status(404).json({ message: 'Sales user not found' });
    }

    if (req.user.role !== 'owner' && salesUser.tenantId !== req.user?.tenantId) {
      return res.status(403).json({ message: 'Not authorized to delete this sales account' });
    }

    await salesUser.delete();
    res.json({ message: 'Sales account deleted successfully', id: salesUser._id || salesUser.id });
  } catch (error) {
    console.error('Sales account delete error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.post('/business-logo-upload-url', protect, isHardwareManagerOrOwner, async (req, res) => {
  try {
    const { contentType, fileSize } = req.body || {};
    if (!['image/png', 'image/jpeg'].includes(contentType)) {
      return res.status(400).json({ message: 'Business logo must be a PNG or JPEG image.' });
    }
    if (!Number.isInteger(fileSize) || fileSize < 1 || fileSize > 200 * 1024) {
      return res.status(400).json({ message: 'Business logo must be up to 200 KB.' });
    }

    const accountId = String(req.user?.tenantId || req.user?._id || req.user?.id || '');
    if (!accountId) {
      return res.status(400).json({ message: 'Business account is required to upload a logo.' });
    }

    const extension = contentType === 'image/png' ? '.png' : '.jpg';
    const key = `business-logos/${accountId}/${Date.now()}-${Math.random().toString(36).slice(2)}${extension}`;
    const command = new PutObjectCommand({
      Bucket: s3BucketName,
      Key: key,
      ContentType: contentType,
      ContentLength: fileSize
    });
    const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 300 });

    return res.json({
      uploadUrl,
      url: `https://${s3BucketName}.s3.${s3Region}.amazonaws.com/${key}`,
      key,
      headers: {
        'Content-Type': contentType
      }
    });
  } catch (error) {
    console.error('Business logo upload URL error:', error);
    return res.status(500).json({ message: 'Failed to prepare business logo upload.' });
  }
});

router.get('/business-settings', protect, (req, res) => {
  const savedSettings = req.tenant?.businessSettings || req.user?.businessSettings;
  const defaultSettings = {
    ...DEFAULT_BUSINESS_SETTINGS,
    name: req.tenant?.shopName || req.user?.shopName || ''
  };

  res.json({
    settings: { ...defaultSettings, ...(savedSettings || {}) },
    configured: Boolean(savedSettings)
  });
});

router.put('/business-settings', protect, isHardwareManagerOrOwner, async (req, res) => {
  try {
    const taxRate = Number(req.body?.taxRate);
    if (!Number.isFinite(taxRate) || taxRate < 0 || taxRate > 100) {
      return res.status(400).json({ message: 'VAT rate must be between 0 and 100.' });
    }

    const existingSettings = req.tenant?.businessSettings || req.user?.businessSettings || {};
    const currency = normalizeCurrencyCode(
      req.body?.currency ?? existingSettings.currency ?? 'MWK'
    );
    if (!isValidCurrencyCode(currency)) {
      return res.status(400).json({ message: 'Select a supported ISO currency code.' });
    }
    const logoKey = String(req.body?.logoKey ?? existingSettings.logoKey ?? '');
    const accountId = String(req.user?.tenantId || req.user?._id || req.user?.id || '');
    if (logoKey && !logoKey.startsWith(`business-logos/${accountId}/`)) {
      return res.status(400).json({ message: 'Business logo key is invalid for this account.' });
    }
    const region = process.env.AWS_REGION || 'us-east-1';
    const logo = logoKey
      ? `https://${s3BucketName}.s3.${region}.amazonaws.com/${logoKey}`
      : '';
    let paymentMethods;
    try {
      paymentMethods = normalizePaymentMethods(
        req.body?.paymentMethods ?? existingSettings.paymentMethods
      );
    } catch (validationError) {
      return res.status(400).json({ message: validationError.message });
    }
    if (!paymentMethods.some((method) => method.enabled)) {
      return res.status(400).json({ message: 'Enable at least one payment method.' });
    }

    const settings = {
      name: String(req.body?.name || '').trim(),
      address: String(req.body?.address || '').trim(),
      phone: String(req.body?.phone || '').trim(),
      email: String(req.body?.email || '').trim(),
      taxId: String(req.body?.taxId || '').trim(),
      taxCompliant: req.body?.taxCompliant === true,
      taxRate,
      currency,
      paymentMethods,
      bankName: String(req.body?.bankName ?? existingSettings.bankName ?? '').trim(),
      bankBranch: String(req.body?.bankBranch ?? existingSettings.bankBranch ?? '').trim(),
      bankAccountName: String(req.body?.bankAccountName ?? existingSettings.bankAccountName ?? '').trim(),
      bankAccountNumber: String(req.body?.bankAccountNumber ?? existingSettings.bankAccountNumber ?? '').trim(),
      receiptFooter: String(req.body?.receiptFooter || '').trim(),
      logo,
      logoKey
    };

    if (req.user?.tenantId) {
      const tenant = await Tenant.findById(req.user.tenantId);
      if (!tenant) {
        return res.status(404).json({ message: 'Tenant not found' });
      }

      tenant.businessSettings = settings;
      await tenant.save();
    } else if (req.user?.role === 'owner') {
      const owner = await User.findById(req.user.id || req.user._id);
      if (!owner) {
        return res.status(404).json({ message: 'User not found' });
      }

      owner.businessSettings = settings;
      await owner.save();
    } else {
      return res.status(400).json({ message: 'A business account is required to save these settings.' });
    }

    return res.json({ settings, configured: true });
  } catch (error) {
    console.error('Business settings update error:', error);
    return res.status(500).json({ message: error.message || 'Failed to save business settings' });
  }
});

// Role-aware tenant summary
router.get('/tenant-summary', protect, async (req, res) => {
  try {
    if (req.user?.role === 'owner') {
      const tenants = (await Tenant.find()).filter((tenant) => !isDeletedTenant(tenant));
      const users = await User.find();
      const activeTenantIds = new Set(tenants.map((tenant) => String(tenant._id || tenant.id)));
      const activeTenants = tenants.filter((tenant) => tenant.status === 'active').length;
      const suspendedTenants = tenants.filter((tenant) => tenant.status === 'suspended').length;
      const summary = {
        totalTenants: activeTenants + suspendedTenants,
        activeTenants,
        suspendedTenants,
        pendingTenants: tenants.filter((tenant) => tenant.status === 'pending').length,
        hardwareManagers: users.filter((user) => (
          isHardwareManagerUser(user) && activeTenantIds.has(String(user.tenantId || ''))
        )).length,
        salesAccounts: users.filter((user) => (
          user.role === 'sales' && activeTenantIds.has(String(user.tenantId || ''))
        )).length
      };
      return res.json(summary);
    }

    return res.json({
      role: req.user?.role || 'user',
      pendingTenants: 0,
      activeTenants: 0,
      suspendedTenants: 0,
      hardwareManagers: 0,
      salesAccounts: 0
    });
  } catch (error) {
    console.error('Tenant summary error:', error);
    res.status(500).json({ message: error.message });
  }
});

// Global owner can manage tenants/bars
router.get('/tenants', protect, isOwner, async (req, res) => {
  try {
    const tenants = (await Tenant.find()).filter((tenant) => !isDeletedTenant(tenant));
    const users = await User.find();

    const usersById = new Map();
    const managersByTenant = new Map();
    const salesCountByTenant = new Map();

    users.forEach((user) => {
      const userId = user._id || user.id;
      usersById.set(userId, user);

      const tenantId = user.tenantId;
      if (!tenantId) return;

      if (user.role === 'hardware-manager' && !managersByTenant.has(tenantId)) {
        managersByTenant.set(tenantId, user);
      }

      if (user.role === 'sales' && user.isActive) {
        salesCountByTenant.set(tenantId, (salesCountByTenant.get(tenantId) || 0) + 1);
      }
    });

    const enrichedTenants = tenants.map((tenant) => {
      const tenantId = tenant._id || tenant.id;
      const owner = tenant.ownerId ? usersById.get(tenant.ownerId) : null;
      const registeredManager = managersByTenant.get(tenantId) || null;
      const activeSalesAccountCount = salesCountByTenant.get(tenantId) || 0;

      const ownerInfo = owner ? {
        id: owner._id || owner.id,
        fullName: owner.fullName || owner.username,
        username: owner.username,
        email: owner.email,
        phone: owner.phone
      } : null;

      const registeredManagerInfo = registeredManager ? {
        id: registeredManager._id || registeredManager.id,
        fullName: registeredManager.fullName || registeredManager.username,
        username: registeredManager.username,
        email: registeredManager.email,
        phone: registeredManager.phone,
        role: registeredManager.role,
        registrationStatus: registeredManager.registrationStatus
      } : null;

      return {
        ...tenant,
        subscriptionAccess: getSubscriptionAccess(tenant),
        ownerInfo,
        registeredManagerInfo,
        activeSalesAccountCount
      };
    });

    res.json(enrichedTenants);
  } catch (error) {
    console.error('Tenant list error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.patch('/tenants/:id/shop-name', protect, isOwner, async (req, res) => {
  try {
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) {
      return res.status(404).json({ message: 'Shop not found' });
    }

    const shopName = String(req.body?.shopName || '').trim();
    if (shopName.length > 120) {
      return res.status(400).json({ message: 'Shop name must be 120 characters or fewer.' });
    }

    tenant.shopName = shopName || null;
    await tenant.save();
    res.json({ message: 'Shop name updated successfully.', tenant });
  } catch (error) {
    console.error('Shop name update error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.patch('/tenants/:id/subscription', protect, isOwner, async (req, res) => {
  try {
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) {
      return res.status(404).json({ message: 'Hardware not found' });
    }

    const termUnit = req.body?.termUnit || (req.body?.termDays !== undefined ? 'days' : 'months');
    const termValue = req.body?.termValue ?? (termUnit === 'days' ? req.body?.termDays : req.body?.termMonths);
    const termMonths = termUnit === 'months' ? normalizeTermMonths(termValue) : null;
    const termDays = termUnit === 'days' ? normalizeTermDays(termValue) : null;
    if ((termUnit !== 'days' && termUnit !== 'months') || (!termMonths && !termDays)) {
      return res.status(400).json({ message: 'Subscription validity must be 1-12 whole months or 1-365 whole days' });
    }

    const gracePeriodUnit = req.body?.gracePeriodUnit || 'days';
    const gracePeriodValue = Number(
      req.body?.gracePeriodValue ?? req.body?.gracePeriodDays ?? DEFAULT_GRACE_PERIOD_DAYS
    );
    const maxGracePeriod = gracePeriodUnit === 'months' ? MAX_GRACE_PERIOD_MONTHS : MAX_GRACE_PERIOD_DAYS;
    if (
      (gracePeriodUnit !== 'days' && gracePeriodUnit !== 'months')
      || !Number.isInteger(gracePeriodValue)
      || gracePeriodValue < 0
      || gracePeriodValue > maxGracePeriod
    ) {
      return res.status(400).json({ message: 'Grace period must be 0-90 whole days or 0-3 whole months' });
    }

    const existingExpiry = tenant.subscriptionEnforced && tenant.subscriptionExpiresAt
      ? new Date(tenant.subscriptionExpiresAt)
      : null;
    const hasFutureExpiry = existingExpiry && !Number.isNaN(existingExpiry.getTime()) && existingExpiry > new Date();
    const dates = buildSubscriptionDates({
      startAt: hasFutureExpiry ? existingExpiry : new Date(),
      ...(termUnit === 'days' ? { termDays } : { termMonths })
    });

    tenant.subscriptionEnforced = true;
    tenant.subscriptionStatus = 'active';
    tenant.subscriptionStartAt = dates.startAt;
    tenant.subscriptionExpiresAt = dates.expiresAt;
    tenant.subscriptionTermMonths = dates.termMonths || null;
    tenant.subscriptionTermDays = dates.termDays || null;
    tenant.gracePeriodUnit = gracePeriodUnit;
    tenant.gracePeriodValue = gracePeriodValue;
    tenant.gracePeriodDays = gracePeriodUnit === 'days' ? gracePeriodValue : null;
    tenant.gracePeriodMonths = gracePeriodUnit === 'months' ? gracePeriodValue : null;
    tenant.subscriptionPaymentReference = String(req.body?.paymentReference || '').trim() || null;
    tenant.subscriptionPaymentMethod = String(req.body?.paymentMethod || '').trim() || null;
    tenant.subscriptionUpdatedAt = new Date().toISOString();
    tenant.subscriptionUpdatedBy = req.user?._id || req.user?.id || null;
    await tenant.save();

    res.json({ tenant, subscriptionAccess: getSubscriptionAccess(tenant) });
  } catch (error) {
    console.error('Tenant subscription update error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.patch('/tenants/:id/suspend', protect, isOwner, async (req, res) => {
  try {
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) {
      return res.status(404).json({ message: 'Bar not found' });
    }

    tenant.status = 'suspended';
    tenant.suspendedAt = new Date().toISOString();
    tenant.suspensionReason = req.body?.reason || 'Suspended by owner';
    await tenant.save();

    const users = await User.find({ tenantId: tenant._id || tenant.id });
    for (const user of users) {
      user.isActive = false;
      await user.save();
    }

    res.json({ message: 'Bar suspended successfully', tenant });
  } catch (error) {
    console.error('Tenant suspend error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.patch('/tenants/:id/restore', protect, isOwner, async (req, res) => {
  try {
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) {
      return res.status(404).json({ message: 'Bar not found' });
    }

    tenant.status = 'active';
    tenant.restoredAt = new Date().toISOString();
    tenant.suspensionReason = '';
    await tenant.save();

    const users = await User.find({ tenantId: tenant._id || tenant.id });
    for (const user of users) {
      if (user.role !== 'owner') {
        user.isActive = true;
        await user.save();
      }
    }

    res.json({ message: 'Bar restored successfully', tenant });
  } catch (error) {
    console.error('Tenant restore error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.delete('/tenants/:id', protect, isOwner, async (req, res) => {
  try {
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) {
      return res.status(404).json({ message: 'Hardware not found' });
    }

    const tenantId = tenant._id || tenant.id;
    const tenantUsers = await User.find({ tenantId });
    for (const tenantUser of tenantUsers) {
      await deleteTenantAndRelatedData(tenantId, tenantUser._id || tenantUser.id);
      await tenantUser.delete();
    }
    await deleteTenantAndRelatedData(tenantId);
    await tenant.delete();

    res.json({ message: 'Hardware and all related data removed successfully', tenant });
  } catch (error) {
    console.error('Tenant delete error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.patch('/tenants/:id/delete', protect, isOwner, async (req, res) => {
  try {
    const tenant = await Tenant.findById(req.params.id);
    if (!tenant) {
      return res.status(404).json({ message: 'Hardware not found' });
    }

    const tenantId = tenant._id || tenant.id;
    const tenantUsers = await User.find({ tenantId });
    for (const tenantUser of tenantUsers) {
      await deleteTenantAndRelatedData(tenantId, tenantUser._id || tenantUser.id);
      await tenantUser.delete();
    }
    await deleteTenantAndRelatedData(tenantId);
    await tenant.delete();

    res.json({ message: 'Hardware and all related data removed successfully', tenant });
  } catch (error) {
    console.error('Tenant delete error:', error);
    res.status(500).json({ message: error.message });
  }
});

// Global owner can list all hardware managers with full details
router.get('/hardware-managers', protect, isOwner, async (req, res) => {
  try {
    const tenants = (await Tenant.find()).filter((tenant) => !isDeletedTenant(tenant));
    const activeTenantIds = new Set(tenants.map((tenant) => String(tenant._id || tenant.id)));
    const managers = (await User.find({ role: 'hardware-manager' })).filter((manager) => (
      activeTenantIds.has(String(manager.tenantId || ''))
    ));
    const normalized = managers.map((manager) => ({
      id: manager._id || manager.id,
      fullName: manager.fullName,
      username: manager.username,
      email: manager.email,
      phone: manager.phone,
      tenantId: manager.tenantId,
      role: manager.role,
      isActive: manager.isActive,
      registrationStatus: manager.registrationStatus,
      createdAt: manager.createdAt,
      updatedAt: manager.updatedAt
    }));
    res.json(normalized);
  } catch (error) {
    console.error('Hardware manager list error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.patch('/change-password', protect, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body || {};
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current password and new password are required' });
    }

    if (String(newPassword).length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters' });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const passwordMatches = await bcrypt.compare(currentPassword, user.password);
    if (!passwordMatches && user.password !== currentPassword) {
      return res.status(401).json({ message: 'Current password is incorrect' });
    }

    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(newPassword, salt);
    await user.save();

    res.json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ message: error.message });
  }
});

router.patch('/hardware-managers/:id/reset-password', protect, isOwner, async (req, res) => {
  try {
    const { newPassword } = req.body || {};
    if (!newPassword || String(newPassword).length < 6) {
      return res.status(400).json({ message: 'A new password of at least 6 characters is required' });
    }

    const manager = await User.findById(req.params.id);
    if (!manager || manager.role !== 'hardware-manager') {
      return res.status(404).json({ message: 'Hardware manager not found' });
    }

    const salt = await bcrypt.genSalt(10);
    manager.password = await bcrypt.hash(newPassword, salt);
    manager.isActive = true;
    await manager.save();

    res.json({ message: `Password reset for ${manager.fullName || manager.username}` });
  } catch (error) {
    console.error('Reset manager password error:', error);
    res.status(500).json({ message: error.message });
  }
});

// Global owner can create public invite link for hardware managers
router.post('/create-invite', protect, isOwner, async (req, res) => {
  try {
    const { tenantId, tenantName, hardwareName, phone, expiresInDays = 7 } = req.body || {};
    const tenant = tenantId ? await Tenant.findById(tenantId) : null;
    const invite = new TenantInvite({
      token: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      tenantId: tenant ? tenant._id || tenant.id : null,
      tenantName: tenantName || tenant?.name || 'Hardware',
      hardwareName: hardwareName || tenant?.hardwareName || 'Hardware',
      phone: phone || null,
      status: 'approved',
      expiresAt: new Date(Date.now() + (Number(expiresInDays) || 7) * 24 * 60 * 60 * 1000).toISOString()
    });
    await invite.save();
    res.status(201).json({ invite });
  } catch (error) {
    console.error('Invite creation error:', error);
    res.status(500).json({ message: error.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const body = req.body || {};
    const loginIdentifier = body.username || body.email || body.userName || body.login;
    const password = body.password;

    if (!loginIdentifier || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    console.log('Login attempt:', { username: loginIdentifier, password: '[REDACTED]' });

    const allUsers = await User.find();
    const identity = resolveLoginIdentity(allUsers, loginIdentifier);
    if (identity.requiresUsername) {
      return res.status(400).json({ message: 'This email is linked to multiple shops. Sign in with your unique username.' });
    }
    if (identity.ambiguousUsername) {
      return res.status(401).json({ message: 'Login conflict. Contact support to resolve duplicate usernames.' });
    }
    const user = identity.user;
    console.log('Login lookup result:', !!user, user ? { id: user._id, username: user.username, role: user.role, isActive: user.isActive, tenantId: user.tenantId } : null);

    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    await normalizeOwnerAccount(user);

    let tenant = null;
    if (user.tenantId) {
      tenant = await Tenant.findById(user.tenantId);
      if (!tenant) {
        return res.status(401).json({ message: 'Tenant not found' });
      }
    }

    if (!user.isActive) {
      return res.status(401).json({ message: 'Account disabled' });
    }

    const accessMessage = getTenantAccessMessage(tenant?.status);
    if (accessMessage) {
      return res.status(403).json({ message: accessMessage });
    }

    let isMatch = false;
    try {
      isMatch = await bcrypt.compare(password, user.password);
    } catch (compareError) {
      console.error('Password compare error:', compareError);
    }

    if (!isMatch && user.password === password) {
      isMatch = true;
    }

    console.log('Login password match:', isMatch);

    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const subscriptionAccess = getSubscriptionAccess(tenant);
    if (!subscriptionAccess.canAccess) {
      return res.status(403).json({
        message: getSubscriptionLoginMessage(subscriptionAccess),
        subscription: subscriptionAccess
      });
    }

    const token = jwt.sign(
      { id: user._id, role: user.role, tenantId: user.tenantId || null },
      jwtSecret,
      { expiresIn: '7d' }
    );

    const tenantStatus = tenant?.status || 'active';
    const suspensionMessage = getTenantAccessMessage(tenantStatus);

    res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        shopName: tenant?.shopName || null,
        hardwareName: tenant?.hardwareName || tenant?.name || null,
        tenantStatus,
        suspensionMessage,
        subscription: subscriptionAccess
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: error.message });
  }
});

// Get current user
router.get('/me', protect, async (req, res) => {
  try {
    const hardwareManager = req.user?.role === 'hardware-manager'
      ? req.user
      : req.user?.tenantId
        ? await User.findOne({ tenantId: req.user.tenantId, role: 'hardware-manager' })
        : null;
    const userPayload = {
      ...req.user,
      shopName: req.tenant?.shopName || null,
      hardwareName: req.tenant?.hardwareName || req.tenant?.name || null,
      hardwareAddress: req.tenant?.address || [
        req.tenant?.town || req.tenant?.tradingCenter,
        req.tenant?.district,
        req.tenant?.country
      ].filter(Boolean).join(', ') || null,
      hardwareManagerName: hardwareManager?.fullName || null,
      hardwareManagerEmail: hardwareManager?.email || null,
      hardwareManagerPhone: hardwareManager?.phone || null,
      tenantStatus: req.tenant?.status || 'active',
      suspensionMessage: getTenantAccessMessage(req.tenant?.status),
      subscription: req.tenant?.subscriptionAccess || getSubscriptionAccess(req.tenant)
    };

    res.json(userPayload);
  } catch (error) {
    console.error('Error getting user:', error);
    res.status(500).json({ message: 'Unable to fetch user' });
  }
});

module.exports = router;
module.exports.ensureDefaultOwnerUser = ensureDefaultOwnerUser;
module.exports.getTenantAccessMessage = getTenantAccessMessage;
module.exports.shouldPromoteToOwner = shouldPromoteToOwner;
module.exports.buildApprovalMessage = buildApprovalMessage;
module.exports.sendWhatsAppApprovalMessage = sendWhatsAppApprovalMessage;
module.exports.getRegistrationConflicts = getRegistrationConflicts;
module.exports.resolveLoginIdentity = resolveLoginIdentity;
module.exports.normalizeShopName = normalizeShopName;
module.exports.getShopNameValidationError = getShopNameValidationError;
module.exports.normalizeShopProfile = normalizeShopProfile;
module.exports.getShopProfileValidationError = getShopProfileValidationError;
module.exports.buildManagerInstructions = buildManagerInstructions;
module.exports.isHardwareManagerUser = isHardwareManagerUser;
module.exports.buildManagerInstructions = buildManagerInstructions;