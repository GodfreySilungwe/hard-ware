const test = require('node:test');
const assert = require('node:assert/strict');
const {
  getTenantAccessMessage,
  shouldPromoteToOwner,
  getRegistrationConflicts,
  resolveLoginIdentity
} = require('../routes/auth');

test('tenant access messages use clear hardware wording', () => {
  assert.equal(getTenantAccessMessage('suspended'), 'This hardware is suspended. Please contact support.');
  assert.equal(getTenantAccessMessage('deleted'), 'This hardware has been deleted and cannot be used.');
  assert.equal(getTenantAccessMessage('active'), null);
});

test('pending hardware-manager accounts stay hardware-scoped even when credentials resemble the owner', () => {
  const ownerConfig = {
    username: 'gsilungwe',
    email: 'silungwegod@gmail.com'
  };

  const pendingHardwareManager = {
    role: 'hardware-manager',
    username: 'gsilungwe',
    email: 'silungwegod@gmail.com',
    registrationStatus: 'pending'
  };

  assert.equal(shouldPromoteToOwner(pendingHardwareManager, ownerConfig), false);
});

test('allows the same email in separate shop registrations but enforces unique usernames', () => {
  const existingUsers = [{ username: 'shop-one', email: 'owner@example.com', tenantId: 'tenant-1' }];

  assert.deepEqual(getRegistrationConflicts(existingUsers, {
    username: 'shop-two',
    email: 'OWNER@example.com',
    tenantId: 'tenant-2'
  }), { usernameExists: false, emailExistsInTenant: false });
  assert.deepEqual(getRegistrationConflicts(existingUsers, {
    username: ' SHOP-ONE ',
    email: 'new@example.com',
    tenantId: 'tenant-2'
  }), { usernameExists: true, emailExistsInTenant: false });
  assert.deepEqual(getRegistrationConflicts(existingUsers, {
    username: 'shop-one-again',
    email: 'OWNER@example.com',
    tenantId: 'tenant-1'
  }), { usernameExists: false, emailExistsInTenant: true });
});

test('requires username for a shared email while retaining single-account email login', () => {
  const users = [
    { username: 'east-shop', email: 'owner@example.com', tenantId: 'tenant-1' },
    { username: 'west-shop', email: 'owner@example.com', tenantId: 'tenant-2' }
  ];

  assert.deepEqual(resolveLoginIdentity(users, 'OWNER@example.com'), {
    user: null,
    ambiguousUsername: false,
    requiresUsername: true
  });
  assert.equal(resolveLoginIdentity(users, 'WEST-SHOP').user, users[1]);
  assert.equal(resolveLoginIdentity([users[0]], 'owner@example.com').user, users[0]);
});
